import 'package:intl/intl.dart';

import '../db/sale_repository.dart' show SaleLine;

String _qty(double v) {
  if (v == v.truncateToDouble()) return v.toInt().toString();
  return v.toStringAsFixed(3).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
}

/// Plain-text customer bill (32 columns — a standard 58mm thermal roll), used
/// by the Print/Share preview and as the plain-text (Copy / WhatsApp) bill.
/// Pure function so it is unit-tested.
String buildSaleBillText({
  required String shopName,
  String shopOwner = '',
  String shopPhone = '',
  required String invoice,
  required DateTime date,
  required String customer,
  required List<SaleLine> lines,
  required double subtotal,
  required double discount,
  required double total,
  required double paid,
  String paymentMethod = 'Cash',
  double? netBalance,
  int width = 32,
}) {
  final b = StringBuffer();
  String center(String t) {
    if (t.length >= width) return t;
    return ' ' * ((width - t.length) ~/ 2) + t;
  }

  String row(String left, String right) {
    final space = width - left.length - right.length;
    if (space >= 1) return left + ' ' * space + right;
    return '$left\n${' ' * (width - right.length)}$right';
  }

  final rule = '-' * width;
  b.writeln(center(shopName.isEmpty ? 'Hanna Medical Store' : shopName));
  if (shopOwner.trim().isNotEmpty) b.writeln(center(shopOwner.trim()));
  if (shopPhone.isNotEmpty) b.writeln(center(shopPhone));
  b.writeln(rule);
  b.writeln('Invoice: $invoice');
  b.writeln('Date: ${DateFormat('dd/MM/yyyy hh:mm a').format(date)}');
  b.writeln('Customer: ${customer.trim().isEmpty ? 'Walk-in' : customer.trim()}');
  b.writeln(rule);
  for (var n = 0; n < lines.length; n++) {
    final l = lines[n];
    b.writeln('${n + 1}. ${l.itemName}');
    b.writeln(row('  ${_qty(l.qty)} ${l.unit} x ${l.unitPrice.toStringAsFixed(2)}', l.amount.round().toString()));
  }
  b.writeln(rule);
  b.writeln('Total Items: ${lines.length}');
  b.writeln(row('Subtotal', subtotal.round().toString()));
  if (discount > 0.009) b.writeln(row('Discount', '-${discount.round()}'));
  b.writeln(row('TOTAL', total.round().toString()));
  b.writeln(row('Paid ($paymentMethod)', paid.round().toString()));
  final due = total - paid;
  if (due > 0.009) b.writeln(row('DUE', due.round().toString()));
  if (netBalance != null) {
    b.writeln(row('Prev Balance', (netBalance - due).round().toString()));
    b.writeln(row('Net Balance', netBalance.round().toString()));
  }
  b.writeln(rule);
  b.writeln(center('Thank you! Please visit again.'));
  return b.toString();
}

/// Plain-text supplier (purchase) bill — Kotlin BillPreviewActivity type "purchase" (party label
/// "Supplier"). Copy / WhatsApp text. Pure function => tested.
/// [lines] = (naam, qty, unit, unitCost, amount).
String buildPurchaseBillText({
  required String shopName,
  String shopOwner = '',
  String shopPhone = '',
  required String billNo,
  required DateTime date,
  required String supplier,
  required List<({String name, double qty, String unit, double unitCost, double amount})> lines,
  required double subtotal,
  required double discount,
  required double total,
  required double paid,
  String paymentMethod = 'Cash',
  double? netBalance,
  int width = 32,
}) {
  final b = StringBuffer();
  String center(String t) {
    if (t.length >= width) return t;
    return ' ' * ((width - t.length) ~/ 2) + t;
  }

  String row(String left, String right) {
    final space = width - left.length - right.length;
    if (space >= 1) return left + ' ' * space + right;
    return '$left\n${' ' * (width - right.length)}$right';
  }

  final rule = '-' * width;
  b.writeln(center(shopName.isEmpty ? 'Hanna Medical Store' : shopName));
  if (shopOwner.trim().isNotEmpty) b.writeln(center(shopOwner.trim()));
  if (shopPhone.isNotEmpty) b.writeln(center(shopPhone));
  b.writeln(center('PURCHASE BILL'));
  b.writeln(rule);
  b.writeln('Bill No: $billNo');
  b.writeln('Date: ${DateFormat('dd/MM/yyyy hh:mm a').format(date)}');
  b.writeln('Supplier: ${supplier.trim().isEmpty ? 'Cash Purchase' : supplier.trim()}');
  b.writeln(rule);
  for (var n = 0; n < lines.length; n++) {
    final l = lines[n];
    b.writeln('${n + 1}. ${l.name}');
    b.writeln(row('  ${_qty(l.qty)} ${l.unit} x ${l.unitCost.toStringAsFixed(2)}', l.amount.round().toString()));
  }
  b.writeln(rule);
  b.writeln('Total Items: ${lines.length}');
  b.writeln(row('Subtotal', subtotal.round().toString()));
  if (discount > 0.009) b.writeln(row('Discount', '-${discount.round()}'));
  b.writeln(row('TOTAL', total.round().toString()));
  b.writeln(row('Paid ($paymentMethod)', paid.round().toString()));
  final due = total - paid;
  if (due > 0.009) b.writeln(row('DUE', due.round().toString()));
  if (netBalance != null) {
    b.writeln(row('Prev Balance', (netBalance - due).round().toString()));
    b.writeln(row('Net Balance', netBalance.round().toString()));
  }
  return b.toString();
}

/// Purchase RETURN receipt (supplier ko dikhane ke liye ke maal wapas hua aur uska balance minus hua).
String buildPurchaseReturnText({
  required String shopName,
  String shopOwner = '',
  String shopPhone = '',
  required String billNo,
  required DateTime date,
  required String supplier,
  required List<({String name, double qty, String unit, double unitCost, double amount})> lines,
  required double returnedTotal,
  double? balanceBefore,
  double? balanceAfter,
  double? billTotal,
  double? netTotal,
  int returnCount = 1,
  int width = 32,
}) {
  final b = StringBuffer();
  String center(String t) => t.length >= width ? t : ' ' * ((width - t.length) ~/ 2) + t;
  String row(String left, String right) {
    final space = width - left.length - right.length;
    return space >= 1 ? left + ' ' * space + right : '$left\n${' ' * (width - right.length)}$right';
  }

  final rule = '-' * width;
  b.writeln(center(shopName.isEmpty ? 'Hanna Medical Store' : shopName));
  if (shopOwner.trim().isNotEmpty) b.writeln(center(shopOwner.trim()));
  if (shopPhone.isNotEmpty) b.writeln(center(shopPhone));
  b.writeln(center('PURCHASE RETURN'));
  b.writeln(center('(Maal wapsi)'));
  b.writeln(rule);
  b.writeln('Bill No: $billNo');
  b.writeln('Date: ${DateFormat('dd/MM/yyyy hh:mm a').format(date)}');
  b.writeln('Supplier: ${supplier.trim().isEmpty ? '-' : supplier.trim()}');
  b.writeln(rule);
  b.writeln(center('RETURNED ITEMS'));
  for (var n = 0; n < lines.length; n++) {
    final l = lines[n];
    b.writeln('${n + 1}. ${l.name}');
    b.writeln(row('  ${_qty(l.qty)} ${l.unit} x ${l.unitCost.toStringAsFixed(2)}', '-${l.amount.round()}'));
  }
  b.writeln(rule);
  if (returnCount > 1) b.writeln('($returnCount returns is bill par)');
  if (billTotal != null) b.writeln(row('Bill total', billTotal.round().toString()));
  b.writeln(row('Returned', '-${returnedTotal.round()}'));
  if (netTotal != null) b.writeln(row('Net', netTotal.round().toString()));
  if (balanceBefore != null && balanceAfter != null) {
    b.writeln(rule);
    b.writeln(row('Balance before', balanceBefore.round().toString()));
    b.writeln(row('Balance now', balanceAfter.round().toString()));
    b.writeln(rule);
    b.writeln(center('Supplier balance Rs ${returnedTotal.round()} kam hua'));
  }
  return b.toString();
}

/// Sale RETURN receipt (customer ko dikhane ke liye ke maal wapas hua aur uska balance minus hua).
String buildSaleReturnText({
  required String shopName,
  String shopOwner = '',
  String shopPhone = '',
  required String invoice,
  required DateTime date,
  required String customer,
  required List<({String name, double qty, String unit, double rate, double amount})> lines,
  required double returnedTotal,
  double? balanceBefore,
  double? balanceAfter,
  double? billTotal,
  double? netTotal,
  int returnCount = 1,
  int width = 32,
}) {
  final b = StringBuffer();
  String center(String t) => t.length >= width ? t : ' ' * ((width - t.length) ~/ 2) + t;
  String row(String left, String right) {
    final space = width - left.length - right.length;
    return space >= 1 ? left + ' ' * space + right : '$left\n${' ' * (width - right.length)}$right';
  }

  final rule = '-' * width;
  b.writeln(center(shopName.isEmpty ? 'Hanna Medical Store' : shopName));
  if (shopOwner.trim().isNotEmpty) b.writeln(center(shopOwner.trim()));
  if (shopPhone.isNotEmpty) b.writeln(center(shopPhone));
  b.writeln(center('SALE RETURN'));
  b.writeln(center('(Maal wapsi)'));
  b.writeln(rule);
  b.writeln('Invoice: $invoice');
  b.writeln('Date: ${DateFormat('dd/MM/yyyy hh:mm a').format(date)}');
  b.writeln('Customer: ${customer.trim().isEmpty ? 'Walk-in' : customer.trim()}');
  b.writeln(rule);
  b.writeln(center('RETURNED ITEMS'));
  for (var n = 0; n < lines.length; n++) {
    final l = lines[n];
    b.writeln('${n + 1}. ${l.name}');
    b.writeln(row('  ${_qty(l.qty)} ${l.unit} x ${l.rate.toStringAsFixed(2)}', '-${l.amount.round()}'));
  }
  b.writeln(rule);
  if (returnCount > 1) b.writeln('($returnCount returns is bill par)');
  if (billTotal != null) b.writeln(row('Bill total', billTotal.round().toString()));
  b.writeln(row('Returned', '-${returnedTotal.round()}'));
  if (netTotal != null) b.writeln(row('Net', netTotal.round().toString()));
  if (balanceBefore != null && balanceAfter != null) {
    b.writeln(rule);
    b.writeln(row('Balance before', balanceBefore.round().toString()));
    b.writeln(row('Balance now', balanceAfter.round().toString()));
    b.writeln(rule);
    b.writeln(center('Customer balance Rs ${returnedTotal.round()} kam hua'));
  }
  return b.toString();
}

/// Kotlin sharePurchase(): chhota summary text (supplier, bill no, amount, balance, date).
String buildPurchaseShareText({
  required String supplier,
  required String billNo,
  required double total,
  required double balance,
  required DateTime date,
}) =>
    [
      'Purchase Bill',
      'Supplier: $supplier',
      'Bill No: $billNo',
      'Amount: Rs ${total.round()}',
      'Balance: Rs ${balance.round()}',
      'Date: ${DateFormat('dd MMM yyyy').format(date)}',
    ].join('\n');
